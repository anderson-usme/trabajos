import React, { useState, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';  

// Importar los componentes
import Login from './components/login';
import Servidores from './components/servidores';
import Home from './pages/home';
import Register from './pages/register';
import Navbar from './components/navbar'; // Barra de navegación
import ProtectedRoute from './components/ProtectedRoute'; // Ruta protegida

// Importar los estilos
import './css/global.css';      // Estilos globales
import './css/login.css';       // Estilos de Login
import './css/home.css';        // Estilos de Home
import './css/servidores.css';  // Estilos de Servidores

function App() {
  // Estado del token
  const [token, setToken] = useState(localStorage.getItem('token'));

  // Función para manejar el login
  const handleLogin = (newToken) => {
    console.log("Login triggered with token:", newToken);  // Verificación en el login
    localStorage.setItem('token', newToken);
    setToken(newToken);
  };

  // Función para manejar el logout
  const handleLogout = () => {
    console.log("Logout triggered");  // Verificación en el logout
    localStorage.removeItem('token');
    setToken(null);
  };

  // Verificación del token cuando se monta el componente
  useEffect(() => {
    console.log("useEffect triggered");  // Verificación de useEffect
    const savedToken = localStorage.getItem('token');
    if (savedToken) {
      console.log("Token found in localStorage:", savedToken);  // Verificación de token encontrado
      setToken(savedToken);
    }
  }, []);

  console.log("Rendering App with token:", token);  // Verificación de renderizado

  return (
    <>
      <Navbar onLogout={handleLogout} /> 
      <Routes>
        <Route path="/" element={<Login onLogin={handleLogin} />} />
        <Route path="/register" element={<Register />} />
        <Route
          path="/home"
          element={
            <ProtectedRoute token={token}>
              <Home onLogout={handleLogout} />
            </ProtectedRoute>
          }
        />
        <Route
          path="/servidores"
          element={
            <ProtectedRoute token={token}>
              <Servidores token={token} />
            </ProtectedRoute>
          }
        />
      </Routes>
    </>
  );
}

export default App;


