import React from 'react';
import Navbar from '../components/navbar';
import '../css/home.css';  


function Home() {
  return (
    <div>
      <Navbar />
      <div className="home-container">
        <h1>Bienvenido a la Administración de Servidores</h1>
        <p>Utiliza el menú superior para navegar entre las secciones.</p>
      </div>
    </div>
  );
}

export default Home;

