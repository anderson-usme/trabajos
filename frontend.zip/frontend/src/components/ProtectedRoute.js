import React from 'react';
import { Navigate } from 'react-router-dom';

const ProtectedRoute = ({ children, token }) => {
  if (!token) {
    // Redirigir al login si no hay token
    return <Navigate to="/" />;
  }

  return children; // Renderiza la ruta protegida si el token es válido
};

export default ProtectedRoute;
