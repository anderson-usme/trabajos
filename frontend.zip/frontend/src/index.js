import React from 'react';
import ReactDOM from 'react-dom/client'; // Cambiar importación
import './index.css'; // Archivo CSS global
import App from './App';
import { BrowserRouter } from 'react-router-dom'; // Importar BrowserRouter

const root = ReactDOM.createRoot(document.getElementById('root')); // Crear el "root"
root.render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);



