import React, { useState, useEffect } from 'react';
import axios from 'axios';

function Servidores({ token }) {
  const [servidores, setServidores] = useState([]);
  const [nuevoServidor, setNuevoServidor] = useState('');
  const [error, setError] = useState('');
  const [mensaje, setMensaje] = useState('');

  const fetchServidores = async () => {
    try {
      const response = await axios.get('/api/check_url/', {
        headers: { Authorization: `Bearer ${token}` },
      });
      setServidores(response.data.data);
      setMensaje('');
    } catch (err) {
      setError('Error al cargar los servidores.');
    }
  };

  const agregarServidor = async () => {
    if (!nuevoServidor) {
      setError('El nombre del servidor no puede estar vacío.');
      return;
    }
    try {
      await axios.post('/api/agregar_servidor/', { name: nuevoServidor }, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setNuevoServidor('');
      setMensaje('Servidor agregado exitosamente.');
      fetchServidores();
    } catch (err) {
      setError('Error al agregar el servidor.');
    }
  };

  const eliminarServidor = async (serverName) => {
    try {
      await axios.delete(`/api/eliminar_servidor/${serverName}/`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      fetchServidores();
      setMensaje(`Servidor ${serverName} eliminado exitosamente.`);
    } catch (err) {
      setError('Error al eliminar el servidor.');
    }
  };

  useEffect(() => {
    fetchServidores();
  }, [token]);

  return (
    <div className="servidores">
      <h2>Gestión de Servidores</h2>
      <div>
        <input
          type="text"
          value={nuevoServidor}
          onChange={(e) => setNuevoServidor(e.target.value)}
        />
        <button onClick={agregarServidor}>Agregar Servidor</button>
      </div>

      {error && <p className="error">{error}</p>}
      {mensaje && <p className="success">{mensaje}</p>}

      <ul>
        {servidores.map((servidor, index) => (
          <li key={index}>
            {servidor.name}
            <button onClick={() => eliminarServidor(servidor.name)}>Eliminar</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Servidores;


